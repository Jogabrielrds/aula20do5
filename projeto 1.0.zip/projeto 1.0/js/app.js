 // Sistema de navegação ativa
document.addEventListener('DOMContentLoaded', function() {
    // Ativar link do menu atual
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        const linkPage = link.getAttribute('href');
        if (linkPage === currentPage) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });

    // Sistema do formulário de contato
    const form = document.getElementById('formContato');
    const lista = document.getElementById('listaContatos');
    const btnListar = document.getElementById('btnListar');

    // Enviar formulário
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(form);
            const data = {
                nome: formData.get('nome'),
                email: formData.get('email'),
                telefone: formData.get('telefone'),
                assunto: formData.get('assunto'),
                mensagem: formData.get('mensagem')
            };

            try {
                const response = await fetch('../php/contato_create.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });

                const result = await response.json();

                if (result.success) {
                    alert('✅ Mensagem enviada com sucesso! ID: ' + result.id);
                    form.reset();
                    
                    // Atualizar lista se estiver visível
                    if (lista && lista.innerHTML !== '') {
                        listarContatos();
                    }
                } else {
                    alert('❌ Erro ao enviar mensagem: ' + (result.error || 'Erro desconhecido'));
                }
            } catch (error) {
                alert('❌ Erro de conexão: ' + error.message);
                console.error('Erro:', error);
            }
        });
    }

    // Listar mensagens
    if (btnListar) {
        btnListar.addEventListener('click', listarContatos);
    }

    // Função para listar contatos
    async function listarContatos() {
        if (!lista) return;
        
        lista.innerHTML = '<div class="item">📡 Carregando mensagens...</div>';
        
        try {
            const response = await fetch('../php/contato_read.php');
            const contatos = await response.json();

            if (Array.isArray(contatos) && contatos.length > 0) {
                lista.innerHTML = contatos.map(contato => `
                    <div class="item">
                        <strong>${escapeHTML(contato.nome)}</strong> 
                        - ${escapeHTML(contato.email)}
                        ${contato.telefone ? ` - 📞 ${escapeHTML(contato.telefone)}` : ''}
                        ${contato.assunto ? ` - 📋 ${escapeHTML(contato.assunto)}` : ''}
                        <div style="margin: 8px 0; padding: 8px; background: #f8f9fa; border-radius: 6px;">
                            ${escapeHTML(contato.mensagem)}
                        </div>
                        <small>📅 ${contato.criado_em}</small>
                    </div>
                `).join('');
            } else {
                lista.innerHTML = '<div class="item">📭 Nenhuma mensagem encontrada.</div>';
            }
        } catch (error) {
            lista.innerHTML = '<div class="item">❌ Erro ao carregar mensagens: ' + error.message + '</div>';
            console.error('Erro:', error);
        }
    }

    // Efeitos interativos para cards
    const interactiveCards = document.querySelectorAll('.area-card, .mini-card, .proj');
    
    interactiveCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Smooth scroll para âncoras
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Animação de entrada para elementos
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observar elementos para animação
    document.querySelectorAll('.card-skill, .area-card, .proj, .mini-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Função utilitária para evitar XSS
function escapeHTML(str) {
    if (!str) return '';
    return str
        .toString()
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// Loading state para botões
function setButtonLoading(button, isLoading) {
    if (isLoading) {
        button.disabled = true;
        button.innerHTML = '⏳ Enviando...';
    } else {
        button.disabled = false;
        button.innerHTML = '📨 Enviar Mensagem';
    }
}

// Validação de formulário em tempo real
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('formContato');
    if (form) {
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                clearFieldError(this);
            });
        });
    }
});

function validateField(field) {
    const value = field.value.trim();
    clearFieldError(field);
    
    if (field.hasAttribute('required') && !value) {
        showFieldError(field, 'Este campo é obrigatório');
        return false;
    }
    
    if (field.type === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            showFieldError(field, 'Por favor, insira um email válido');
            return false;
        }
    }
    
    return true;
}

function showFieldError(field, message) {
    field.style.borderColor = '#ff6b6b';
    
    let errorElement = field.parentNode.querySelector('.error-message');
    if (!errorElement) {
        errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.style.color = '#ff6b6b';
        errorElement.style.fontSize = '12px';
        errorElement.style.marginTop = '4px';
        field.parentNode.appendChild(errorElement);
    }
    
    errorElement.textContent = message;
}

function clearFieldError(field) {
    field.style.borderColor = '#e6eefb';
    
    const errorElement = field.parentNode.querySelector('.error-message');
    if (errorElement) {
        errorElement.remove();
    }
}