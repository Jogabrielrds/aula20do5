document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contact-form");
  const listButton = document.getElementById("btnListar");
  const listContainer = document.getElementById("listaContatos");

  if (form) {
    form.addEventListener("submit", async (event) => {
      event.preventDefault();

      // Lê os campos pelo atributo name do formulário
      const nameInput = form.querySelector('input[name="nome"]');
      const emailInput = form.querySelector('input[name="email"]');
      const phoneInput = form.querySelector('input[name="telefone"]');
      const subjectSelect = form.querySelector('select[name="assunto"]');
      const messageTextarea = form.querySelector('textarea[name="mensagem"]');

      const data = {
        name: nameInput ? nameInput.value.trim() : "",
        email: emailInput ? emailInput.value.trim() : "",
        phone: phoneInput ? phoneInput.value.trim() : "",
        subject: subjectSelect ? subjectSelect.value.trim() : "",
        message: messageTextarea ? messageTextarea.value.trim() : ""
      };

      if (!data.name || !data.email || !data.subject || !data.message) {
        alert("Por favor, preencha todos os campos obrigatórios.");
        return;
      }

      try {
        const response = await fetch("../php/contact.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
          alert("Mensagem enviada com sucesso!");
          form.reset();
          if (listButton) {
            // Atualiza a lista após enviar
            listButton.click();
          }
        } else {
          alert("Erro ao enviar: " + (result.message || "Tente novamente mais tarde."));
        }
      } catch (error) {
        console.error(error);
        alert("Erro de conexão com o servidor.");
      }
    });
  }

  if (listButton && listContainer) {
    listButton.addEventListener("click", async () => {
      try {
        const response = await fetch("../php/contact.php?listar=1");
        const result = await response.json();

        if (!result.success) {
          alert("Erro ao listar mensagens: " + (result.message || ""));
          return;
        }

        const mensagens = result.data || [];

        if (mensagens.length === 0) {
          listContainer.innerHTML = "<p>Nenhuma mensagem cadastrada ainda.</p>";
          return;
        }

        const itens = mensagens
          .map((m) => {
            const dataText = m.criado_em ? " - <small>" + m.criado_em + "</small>" : "";
            const assunto = m.assunto || "Sem assunto";
            const telefone = m.telefone ? " | Tel: " + m.telefone : "";
            return "<li><strong>" + m.nome + "</strong> (" + m.email + telefone + ")" +
                   dataText + "<br>Assunto: " + assunto + "<br>Mensagem: " + m.mensagem + "</li>";
          })
          .join("");

        listContainer.innerHTML = "<ul class=\"lista-mensagens\">" + itens + "</ul>";
      } catch (error) {
        console.error(error);
        alert("Erro ao carregar mensagens do servidor.");
      }
    });
  }
});
