<?php
header('Content-Type: application/json; charset=utf-8');

// CONFIGURAÇÃO DO BANCO ----------------------
$host = "localhost";
$user = "root";
$pass = "";  // no XAMPP, a senha padrão do root é vazia
$db   = "canes_portfolio";

// Conecta ao MySQL
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    echo json_encode([
        "success" => false,
        "message" => "Erro na conexão com o banco: " . $conn->connect_error
    ]);
    exit;
}

// Garante que a tabela exista
$createTableSql = "CREATE TABLE IF NOT EXISTS contatos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    telefone VARCHAR(50) NULL,
    assunto VARCHAR(150) NULL,
    mensagem TEXT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

if (!$conn->query($createTableSql)) {
    echo json_encode([
        "success" => false,
        "message" => "Erro ao criar/verificar tabela: " . $conn->error
    ]);
    $conn->close();
    exit;
}

// LISTAR MENSAGENS (GET)
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["listar"])) {
    $result = $conn->query("SELECT id, nome, email, telefone, assunto, mensagem, criado_em FROM contatos ORDER BY criado_em DESC");

    if (!$result) {
        echo json_encode([
            "success" => false,
            "message" => "Erro ao buscar mensagens: " . $conn->error
        ]);
        $conn->close();
        exit;
    }

    $dados = [];
    while ($row = $result->fetch_assoc()) {
        $dados[] = $row;
    }

    echo json_encode([
        "success" => true,
        "data" => $dados
    ]);
    $conn->close();
    exit;
}

// SALVAR MENSAGEM (POST)
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Método não suportado."
    ]);
    $conn->close();
    exit;
}

$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "Dados inválidos."
    ]);
    $conn->close();
    exit;
}

// Lê os campos esperados
$name    = isset($data["name"])    ? trim($data["name"])    : "";
$email   = isset($data["email"])   ? trim($data["email"])   : "";
$phone   = isset($data["phone"])   ? trim($data["phone"])   : "";
$subject = isset($data["subject"]) ? trim($data["subject"]) : "";
$message = isset($data["message"]) ? trim($data["message"]) : "";

if ($name === "" || $email === "" || $subject === "" || $message === "") {
    echo json_encode([
        "success" => false,
        "message" => "Preencha todos os campos obrigatórios."
    ]);
    $conn->close();
    exit;
}

// Prepara o INSERT
$stmt = $conn->prepare("INSERT INTO contatos (nome, email, telefone, assunto, mensagem)
                        VALUES (?, ?, ?, ?, ?)");

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Erro no prepare: " . $conn->error
    ]);
    $conn->close();
    exit;
}

$stmt->bind_param("sssss", $name, $email, $phone, $subject, $message);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Mensagem enviada com sucesso!"]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Erro ao salvar mensagem: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
